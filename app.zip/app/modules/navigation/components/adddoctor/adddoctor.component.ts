import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { NgModule } from '@angular/core';
import { DoctorService } from '../../services/doctor.service';
import { Doctor } from '../../models/doctor';

@Component({
  selector: 'app-adddoctor',
  templateUrl: './adddoctor.component.html',
  styleUrls: ['./adddoctor.component.css']
})
export class AdddoctorComponent implements OnInit {
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  constructor(private doctorService:DoctorService,private _formBuilder: FormBuilder) {}

  
  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstName: ['', Validators.required],
      lastName:['', Validators.required],
      gender:['', Validators.required],
     
    });
    this.secondFormGroup = this._formBuilder.group({
      specaility: ['', Validators.required],
      branch: ['', Validators.required],
      fee: ['', Validators.required],
    });
  }
  
  saveDoctor(){
    let firstName = this.firstFormGroup.controls['firstName'].value;
    let lastName = this.firstFormGroup.controls['lastName'].value;
    let gender = this.firstFormGroup.controls['gender'].value;
    let specaility = this.secondFormGroup.controls['specaility'].value;
    let branch = this.secondFormGroup.controls['branch'].value;
    let fee = this.secondFormGroup.controls['fee'].value;

    let doctor = new Doctor(firstName , lastName , gender , fee , specaility , branch);
    console.log(doctor);
    this.doctorService.createDoctor(doctor).subscribe(data => console.log(data) 
    ,  error => console.log(error))
  }

  form1(){
    console.log(this.firstFormGroup.value);
  }

  form2(){
    console.log(this.secondFormGroup.value);
  }

}
