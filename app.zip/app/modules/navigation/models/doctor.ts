export class Doctor {

// firstName :string;
// lastName : string;
// gender :string;
// fee : number;
// speciality:string;
// branch:string;

constructor(public firstName :string,
    public    lastName : string,
    public  gender :string,
    public  fee : number,
    public  speciality:string,
    public  branch:string ){}



}
