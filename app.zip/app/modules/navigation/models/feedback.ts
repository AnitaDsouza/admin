export class Feedback {

    constructor( feedbackMessage:string,  rate:number,  userMail:string){}
    
}
