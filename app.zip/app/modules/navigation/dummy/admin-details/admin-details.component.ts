import { Component, OnInit, Input } from '@angular/core';
import { Admin } from '../../models/admin';
import { AdminService } from '../../services/admin.service';
import { AdminListComponent } from '../admin-list/admin-list.component';

@Component({
  selector: 'app-admin-details',
  templateUrl: './admin-details.component.html',
  styleUrls: ['./admin-details.component.css']
})
export class AdminDetailsComponent implements OnInit {

  admin: Admin[];

  constructor(private adminService: AdminService, private listComponent: AdminListComponent) { }

  ngOnInit() {
    this.adminService.getAdminList().subscribe(data => {this.admin=data;} )
  };
}
